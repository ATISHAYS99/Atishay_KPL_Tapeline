''' In this file we will read  '''
#Importing required dependencies
import pandas as pd
import numpy as np
import warnings
import datetime 
import math
warnings.filterwarnings('ignore')
from ..Setups.Database.connection import Conn
from ..Setups.Loggers.Logger import Logs
import re

class Production:
    def __init__(self,engine, conx):
        self.engine = engine
        self.conx = conx
        self.Logs = Logs()
        
        self.prod_df = pd.DataFrame()
        self.breakdown_df = pd.DataFrame()
        self.prod_data = []
        self.breakdown_data = []
        self.breakdown_duration = []
    
    def read_production_data (self):
        try :
            query = "SELECT * FROM [Algo8].[dbo].[TapeProduction]"
            self.prod_df = pd.read_sql(query, self.engine)
            self.prod_data = self.prod_df.values.tolist() 
            self.Logs.Logging("File :generate_schedule, Function : read_production_data, Status: executed")
            return self.prod_data
        except Exception as e :
            self.Logs.Logging(f"File :generate_schedule, Function : read_production_data, Status: not executed, Reason : {e}")
        
    
    def read_breakdown_data (self):
        try : 
            query = "SELECT * FROM [Algo8].[dbo].[TapePlantBreakdown]"
            self.breakdown_df = pd.read_sql(query, self.engine)
            self.breakdown_data = self.breakdown_df.values.tolist()
            
            self.Logs.Logging("File :generate_schedule, Function : read_breakdown_data, Status: executed")
            return  self.breakdown_data
        except Exception as e :
            self.Logs.Logging(f"File :generate_schedule, Function : read_breakdown_data, Status: not executed, Reason : {e}")
        
        
    def calculate_breakdown_duration(self,breakdown_data):
        try :
            for prod in self.prod_data:
                total_breakdown_time = 0
                for breakdown in breakdown_data:
                    if self.is_same_machine(prod, breakdown) and self.is_breakdown_within_production(prod, breakdown):
                        breakdown_minutes = self.convert_to_minutes(breakdown[4])
                        total_breakdown_time += breakdown_minutes
                self.breakdown_duration.append(total_breakdown_time)
            self.prod_df['Breakdown_duration (in min)'] = self.breakdown_duration
            self.Logs.Logging("File :generate_schedule, Function : calculate_breakdown_duration, Status: executed") 
            return self.prod_df 
        except Exception as e :
            self.Logs.Logging(f"File :generate_schedule, Function : calculate_breakdown_duration, Status: not executed, Reason : {e}")
    
    #Check if production and breakdown machine are same 
    def is_same_machine(self, prod, breakdown):
        return prod[2] == breakdown[0]
    
    #Check if breakdown is between production
    def is_breakdown_within_production(self, prod, breakdown):
        return prod[19] <= breakdown[2] and breakdown[3] <= prod[20]
    
    # Convert time into duration (in min)
    def convert_to_minutes(self, time_str):
        breakdown_minutes = sum(int(x) * 60 ** i for i, x in enumerate(reversed(time_str.split(":")))) / 60
        return breakdown_minutes

class ProductionAnalyzer:
    def __init__(self, prod_df):
        self.prod_df = prod_df
    #Convert production hours into min 
    def convert_prod_hours_to_minutes(self):
        prodmins = []
        for value in self.prod_df['ProdHours']:
            minutes = sum(int(x) * 60 ** i for i, x in enumerate(reversed(value.split(":")))) / 60
            prodmins.append(minutes)
        self.prod_df['prodMins'] = prodmins
    
    #Calculate actual time 
    def calculate_actual_time(self):
        self.prod_df['Actual_time(in min)'] = self.prod_df['prodMins'] - self.prod_df['Breakdown_duration (in min)']
    
    # Calculate velocity 
    def calculate_velocity(self):
        self.prod_df['Velocity'] = self.prod_df['ProdInKg'] / self.prod_df['Actual_time(in min)']
    #Analyze velocity for each tape 
    def used_machine_velocity_by_tape(self,TapeId):
        unique_machine = self.prod_df['MachineName'].unique()
        for tape in [TapeId]:
            machine_and_velocity = []
            velocity_for_each_machine = []
            used_machine = []
            average_velocity_for_each_machine = []
            for machine in unique_machine:
                filtered_df = self.prod_df.loc[(self.prod_df['TapeId'] == tape) & (self.prod_df['MachineName'] == machine)& (self.prod_df['Actual_time(in min)'] != 0)].copy()
                if filtered_df.shape[0] > 0:
                    velocity_for_each_machine.append(list(filtered_df['Velocity']))
                    used_machine.append(machine)
                    average_velocity_for_each_machine.append(filtered_df['Velocity'].mean())
                    machine_and_velocity.append([filtered_df['Velocity'].mean(),machine])
            machine_and_velocity.sort(reverse = True) 
            
        return machine_and_velocity
    
    def process_tape_prod(self,tape_prod):
        #Extracting the value of Filler , RP and Tape UV
        TapeRP = []
        TapeFiller = []
        TapeUV = []
        for index, row in tape_prod.iterrows():
            tapename = row['TapeName']
            pattern = r"NON UV"
            match = re.search(pattern, tapename, re.IGNORECASE)
            if match:
                TapeUV.append(0)
            else:
                TapeUV.append(1)  
            rp_value = re.search(r'RP-(\d+)%', tapename)
            if rp_value:
                rp_value = rp_value.group(1)
                TapeRP.append(int(rp_value))
            else:
                rp_value = re.search(r'(\d+)%RP', tapename)
                if rp_value:
                    rp_value = rp_value.group(1)
                    TapeRP.append(int(rp_value))
                else:
                    TapeRP.append(0)
            filler_value = re.search(r'(\d+)%FILLER', tapename)
            if filler_value:
                filler_value = filler_value.group(1)
                TapeFiller.append(int(filler_value))
            else:
                alternative_filler_value = re.search(r'\((\d+)% Filler\)', tapename)
                if alternative_filler_value:
                    alternative_filler_value = alternative_filler_value.group(1)
                    TapeFiller.append(int(alternative_filler_value))
                else:
                    TapeFiller.append(0)
        tape_prod['TapeUv'] = TapeUV
        tape_prod['TapeRP'] = TapeRP
        tape_prod['TapeFiller'] = TapeFiller
        return tape_prod
       
    def last_production(self,tape_prod):
        last_prod = []
        for i in range(1,10):
            machine = f"Tape plant {i}"
            filtered_df = tape_prod.loc[tape_prod['MachineName'] == machine].copy()
            filtered_df = filtered_df.sort_values('PlantProd_DateTimeFrom', ascending=False)    
            last_tape_and_description = filtered_df.iloc[0, filtered_df.columns.isin(['TapeId','TapeName','TapeDenier',
                                                                                      'TapeColour','TapeUv','TapeRP','TapeFiller',
                                                                                      'PlantProd_DateTimeTo'])].values
            color_pattern =  re.compile(r'\b([A-Za-z]+)(?=\(|\b)', re.IGNORECASE)
            match = color_pattern.search(last_tape_and_description[2])
            if match:
                color = match.group(1).lower()
                last_tape_and_description[2] = color.lower()
                
            last_tape_and_description = list(last_tape_and_description)
            last_tape_and_description.append(last_tape_and_description.pop(4))
            last_tape_and_description = tuple(last_tape_and_description)
            last_prod.append(last_tape_and_description)
        return list(last_prod)
     
class Bestmachines:
    def __init__(self, demand_df,last_production,analyzer,engine,conx):
        
        self.engine = engine
        self.conx = conx
        self.Logs = Logs()
        
        self.demand_df = demand_df

        self.demand_df = self.demand_df.sort_values(['Tape_Target_Date','TapeDenier'])
        self.demand_df = self.demand_df.drop(['ULFabricBalanceToMake(Mtrs)','Production capacity per day(Mtrs)',
                                    'Tape(Kg)',
                                    'Tape_Load','Tape_Unload','Demand_Source'
                                    ],axis =1)

        self.demand_df = self.demand_df[self.demand_df['Total_Demand']!=0]
        
        self.tape_data_df = pd.DataFrame()
        
        self.tape_data_df = pd.read_sql("SELECT TapeId, TapeWidth, TapeDenier FROM [Algo8].[dbo].[Master_Tape]", engine)
        
        self.analyzer = analyzer
        
        self.schedule = [['TapeId', 'FabricId','Tape_Completion_date','Loom_Location','LoomNo','LoomType',
                          'Tape_name','TapePropertyName','Total_Demand','Initial_Demand','Inventory_Utilised','Weft_Demand',
                          'Warp_Demand',
                          'Warp_rf_Demand',  'PreLogic_FinalFactor','MaterialId', 'TapeFiller','TapeRP',
                          'TapeWidth', 'TapeColour', 'TapeDenier','TapeMarking', 
                          'FabricWarpMesh', 'Tape_Denier', 'TapeUv','RPTAPE','BestMachine','Velocity',
                          ]]
        self.machine_available_from = {}
        for i in range(1, 10):
            self.machine_available_from[f'Tape plant {i}'] = [last_production[i-1][7].strftime('%Y-%m-%d %H:%M:%S')] ##datetime(2023, 6,27 ,14, 0, 0).strftime('%Y-%m-%d %H:%M:%S')
        self.not_sheduled = [['TapeId', 'FabricId','Tape_Completion_date','Loom_Location','LoomNo','LoomType',
                          'Tape_name','TapePropertyName','Total_Demand','Initial_Demand','Inventory_Utilised','Weft_Demand',
                          'Warp_Demand',
                          'Warp_rf_Demand',  'PreLogic_FinalFactor','MaterialId', 'TapeFiller','TapeRP',
                          'TapeWidth', 'TapeColour', 'TapeDenier','TapeMarking', 
                          'FabricWarpMesh', 'Tape_Denier', 'TapeUv','RPTAPE',
                               'Reason']]
        self.machine_for_color_D19 = []
        self.machine_for_color_GR = []
        for i in range(1,10):
            if(last_production[i-1][2] != 'white' and last_production[i-1][2]!='White'):
                if(i<3):
                    self.machine_for_color_D19.append(f'Tape plant {i}')    
                else:
                    self.machine_for_color_GR.append(f'Tape plant {i}')

    def sort_tape_ids_by_nearest_width(self, target_id):
        tape_ids = list(self.tape_data_df['TapeId'])
        tape_widths = list(self.tape_data_df['TapeWidth'])
        target_index = tape_ids.index(target_id)
        target_width = tape_widths[target_index]
        pairs = zip(tape_ids, tape_widths)
        sorted_pairs = sorted(pairs, key=lambda pair: abs(pair[1] - target_width))
        sorted_tape_ids = [pair[0] for pair in sorted_pairs]
        return sorted_tape_ids

    def width_can_be_used(self,width,denier):

        if(width=='Narrow'):
            if(int(denier)<1000):
                return ['Tape plant 5','Tape plant 7']
            elif(int(denier)<=1700):
                return ['Tape plant 5','Tape plant 6','Tape plant 7','Tape plant 8']
            else:
                return ['Tape plant 5','Tape plant 6','Tape plant 8']
        elif(width=='Standard'):
            if(int(denier)<1000):
                return ['Tape plant 5','Tape plant 4','Tape plant 7']
            else:
                return ['Tape plant 5','Tape plant 4','Tape plant 6','Tape plant 7','Tape plant 8']
        else:
            if(int(denier)<1000):
                return ['Tape plant 4','Tape plant 5','Tape plant 7']
            else:
                return ['Tape plant 4','Tape plant 8','Tape plant 5']   
      
    def schedule_tapes(self,analyzer):
        try :
            total_load = {'Tape plant 1':0,'Tape plant 2':0,'Tape plant 3':0,'Tape plant 4':0,'Tape plant 5':0,
                            'Tape plant 6':0,'Tape plant 7':0,'Tape plant 8':0,'Tape plant 9':0}
            for index,row in self.demand_df.iterrows():
                tape_id = row['TapeId']

                machines = ['Tape plant 1','Tape plant 2','Tape plant 3','Tape plant 4','Tape plant 5',
                            'Tape plant 6','Tape plant 7','Tape plant 8','Tape plant 9']
                
                if(row['Loom_Location'] == 'D-19'):
    
                    machine_can_be_used = ['Tape plant 1','Tape plant 2']
                    machines = [element for element in machines if element in machine_can_be_used]

                    if(row['TapeColour'] != 'white'):
                            machine_can_be_used = self.machine_for_color_D19 
                    machines = [element for element in machines if element in machine_can_be_used]

                    if(len(machines)==0):
                        machines.append('Tape plant 2')
                        
                    self.machine_for_color_D19 = machines  
                
                    if (row['TapeWidth'] == 'Narrow' and int(row['TapeDenier'])>1500):
                        machine_can_be_used = ['Tape plant 1']
                        machines = [machine for machine in machines if machine in machine_can_be_used]

                    elif (row['TapeWidth'] == 'Narrow' and int(row['TapeDenier'])<940):
                        machine_can_be_used = ['Tape plant 2']
                        machines = [machine for machine in machines if machine in machine_can_be_used]
                        
                    elif (row['TapeWidth'] == 'Narrow' and int(row['TapeDenier'] >=940  and int(row['TapeDenier'])<=1500)):
                        machine_can_be_used = ['Tape plant 2']
                        machines = [machine for machine in machines if machine in machine_can_be_used]
                        
                    elif (row['TapeWidth']== 'Wider'):
                        machine_can_be_used = ['Tape Plant 1','Tape plant 2']
                        machines = [machine for machine in machines if machine in machine_can_be_used]
                        
                    elif (int(row['TapeDenier']<1000) and int(row['RPTAPE'])==0 ):
                        machine_can_be_used = ['Tape plant 2']
                    
                        machines = [element for element in machines if element in machine_can_be_used]
        
                    elif(int(row['TapeDenier']<1000) and int(row['RPTAPE'])==1 ):
                        self.not_sheduled.append(row.values.tolist() + ['No suggested machine (RP)'])
                        continue
    
                    elif (row['TapeDenier']<1000 and row['TapeFiller']>=10):
                    
                        machine_can_be_used=['Tape plant 2']
                        machines = [element for element in machines if element in machine_can_be_used]
                    elif (row['TapeDenier']<1000 and row['TapeFiller']< 10):
                        machine_can_be_used = []
                        machines = [element for element in machines if element in machine_can_be_used]    

                        if(len(machines)==0):
                            self.not_sheduled.append(row.values.tolist() + ['Filler_required_D-19 (Transfer to Gajner)'])
                            continue
                                        
                    if(len(machines)==0):

                        self.not_sheduled.append(row.values.tolist() + ['No machine suggested for specification'])
                        continue

                else:
    
                    machine_can_be_used = ['Tape plant 4','Tape plant 5','Tape plant 6','Tape plant 7','Tape plant 8','Tape plant 9']    
                    machines = [element for element in machines if element in machine_can_be_used]
                    if(row['TapeColour'] != 'white'):
                        machine_can_be_used = self.machine_for_color_GR
                            
                    machines = [element for element in machines if element in machine_can_be_used]
                    
                    if(len(machines)==0):
                        if(row['TapeRP']<100):
                            machines  = ['Tape plant 5','Tape plant 7']
                        else:
                            machines  = ['Tape plant 7','Tape plant 8']
                    self.machine_for_color_GR = machines

                    if (int(row['TapeDenier'])<1000) and (int(row['RPTAPE'])==1):
                        machine_can_be_used = ['Tape plant 7']
                        machines = [element for element in machines if element in machine_can_be_used]
                        
                    elif (int(row['TapeDenier'])>=1000 and int(row['RPTAPE']==1)):
                        machine_can_be_used = ['Tape plant 5','Tape plant 7','Tape plant 6','Tape plant 8']
                        machines = [element for element in machines if element in machine_can_be_used]
                        
                    elif (int(row['TapeDenier'])<1000) and (int(row['RPTAPE'])==0):
                        machine_can_be_used = ['Tape plant 5','Tape plant 7'] 
                        machines = [element for element in machines if element in machine_can_be_used]   
                        
                    elif (int(row['TapeDenier'])>=1000) and (int(row['RPTAPE'])==0):
                        machine_can_be_used = ['Tape plant 5','Tape plant 4','Tape plant 7'] 
                        machines = [element for element in machines if element in machine_can_be_used]  
                        
                    elif (row['TapeFiller'] >10 and int(row['TapeDenier'])>=1000):
                        machine_can_be_used = ['Tape plant 8','Tape plant 7']
                        machines = [element for element in machines if element in machine_can_be_used]
                        
                    elif(row['TapeFiller'] >10 and int(row['TapeDenier'])<1000):  
                        machine_can_be_used = ['Tape plant 5']
                        machines = [element for element in machines if element in machine_can_be_used]

                    machine_can_be_used = self.width_can_be_used(row['TapeWidth'],row['TapeDenier'])
                    machines = [element for element in machines if element in machine_can_be_used]


                    if(len(machines)==0):
                        self.not_sheduled.append(row.values.tolist() + ['No machine suggested for specification'])
                        continue

                used_machine = analyzer.used_machine_velocity_by_tape(tape_id)

                used_machine = [element for element in used_machine if element[1] in machines]
                not_used_machine = [element for element in machines if element not in [item[1] for item in used_machine]]
                
                for machine in not_used_machine:
                    Tape_id_of_nearest_width = self.sort_tape_ids_by_nearest_width(tape_id) 
                    for tape in Tape_id_of_nearest_width:                        
                        use_machine = self.analyzer.used_machine_velocity_by_tape(tape) 
                        mac = [mach for mach in use_machine if mach[1] == machine] 
                        if mac :
                            used_machine.append(mac[0])
                            break                        
                
                earliest_complete = []
                for machine in used_machine:
                    starttime = datetime.strptime(self.machine_available_from[machine[1]][0], '%Y-%m-%d %H:%M:%S') 
                    total_demand = row['Total_Demand']
                    time_taken = round((total_demand) / machine[0])
                    completion_time = starttime + pd.DateOffset(minutes=time_taken)
                    earliest_complete.append([completion_time, starttime,machine[1],machine[0]])

                earliest_complete.sort()
                best_one = earliest_complete[0]
                best_machine = None
                min_load = float('inf')
                
                for completion_info in earliest_complete:
                    machine_name = completion_info[2]
                    machine_load = total_load.get(machine_name, 0)  

                    if machine_load < min_load:
                        min_load = machine_load
                        best_machine = machine_name
                    
                best_machine = best_one[2]
                total_demand = row['Total_Demand']
                
                total_load[best_machine] += total_demand
                
                self.machine_available_from[best_machine] = [best_one[0].strftime('%Y-%m-%d %H:%M:%S')]
                
                self.schedule.append(row.values.tolist()+ [best_machine,best_one[3]])
            
            self.Logs.Logging("File :generate_schedule, Function : best_machine_schedule_tapes, Status: executed")
            return [self.schedule,self.not_sheduled]
        except Exception as e :
            self.Logs.Logging(f"File :generate_schedule, Function :  best_machine_schedule_tapes, Status: not executed, Reason : {e}")
            
            
class TapeScheduler:
    def __init__(self, schedule_df,last_production,engine,conx):
        print("Tape_Scheduler_Called")
        
        self.engine = engine
        self.conx = conx
        self.Logs = Logs()
        self.schedule_df = schedule_df
        self.changeover_df = pd.DataFrame()
        self.planned_stop_data = pd.DataFrame()
        self.tape_data_df = pd.DataFrame()
        self.denier_step_data = pd.DataFrame()
        self.recipe_change_data = pd.DataFrame()
        
        self.changeover_df = pd.read_sql('SELECT * FROM [Algo8].[dbo].[Tapeline_Changeover_Data]',self.engine)
        
        self.denier_step_data = pd.read_sql('SELECT [TapeType], [DenierChange(1Step)], [Duration in Minutes] FROM [Algo8].[dbo].[Tapeline_ConfiguredRule_DenierStepUpDown]', self.engine)

        self.planned_stop_data = pd.read_sql('SELECT [Tapeline],[StartTime],[EndTime] FROM [Algo8].[dbo].[Tapeline_PlannedStop]',self.engine)

        self.recipe_change_data = pd.read_sql('SELECT [Recipe1],[Recipe2],[Duration in Minutes] FROM [Algo8].[dbo].[Tapeline_ConfiguredRule_RecipeChange]',self.engine)
                
        self.tape_data_df = pd.read_sql("SELECT TapeId, TapeWidth, TapeDenier FROM [Algo8].[dbo].[Master_Tape]", self.engine)
        
        self.schedule = [['Prev_Tape_Id', 'Prev_Tape_name','Prev_Tape_Denier' ,'Prev_Tape_Colour','Tape_id', 'Tape_name','TapePropertyName','Tape_Denier'
                          ,'TapeColour',
                          'TapeMarking','Total_Demand','Weft_demand','Warp_Demand','Warp_rf_Demand',
                          'Tape_demand + Production loss + Wastage',
                          'Target_date', 'Machine','Plant_Location','LoomNo','LoomType','PreLogic_FinalFactor','TapeDenier_Change_Starttime',
                          'TapeDenier_Change_Endtime',
                          'Recipe_change_Starttime','Recipe_change_Endtime','Prod_Start_Time', 'Prod_End_time', 'Plan no.', 
                          'Type of Changeover', 'Production_loss (kg)', 'Wastage (kg)', 'Man power loss (Rs)']]
        self.machine_available_from = {}
        for i in range(1, 10):
            self.machine_available_from[f'Tape plant {i}'] = [last_production[i-1][0], last_production[i-1][3],last_production[i-1][1], 
                                                              last_production[i-1][7].strftime('%Y-%m-%d %H:%M:%S'),1,
                                                              last_production[i-1][2],last_production[i-1][4],last_production[i-1][5],last_production[i-1][6]]
        print("Machine_availability: ",self.machine_available_from)
        
    def get_changeover_data(self, prev_tape_id, tape_id, machine):
        if prev_tape_id == 0:
            return ['no changeover', 0, 0, 0, 0]
        else:
            filter1 = self.schedule_df.loc[(self.schedule_df['TapeId'] == prev_tape_id)].copy()
            filter2 = self.schedule_df.loc[(self.schedule_df['TapeId'] == tape_id)].copy() 
            filter1.reset_index(drop=True, inplace=True)
            filter2.reset_index(drop=True, inplace=True)
            if (not filter1['MaterialId'].equals(filter2['MaterialId'])) and (not filter1['FabricWarpMesh'].equals(filter2['FabricWarpMesh'])):
                changeover = 'recipe+mesh change'
            elif (not filter1['MaterialId'].equals(filter2['MaterialId'])) and (not filter1['TapeWidth'].equals(filter2['TapeWidth'])):
                changeover = 'recipe+cam change'
            elif (not filter1['TapeColour'].equals(filter2['TapeColour'])) and (not filter1['FabricWarpMesh'].equals(filter2['FabricWarpMesh'])):
                changeover = 'color+mesh change'
            elif (not filter1['TapeColour'].equals(filter2['TapeColour'])) and (not filter1['TapeWidth'].equals(filter2['TapeWidth'])):
                changeover = 'color +cam change'
            elif (not filter1['FabricWarpMesh'].equals(filter2['FabricWarpMesh'])):
                changeover = 'Mesh change'
            elif (not filter1['TapeColour'].equals(filter2['TapeColour'])) and (filter2['TapeColour'].equals('white')):
                changeover = 'Color change (Color to white)'
            elif (not filter1['TapeColour'].equals(filter2['TapeColour'])) and (filter1['TapeColour'].equals('white')):
                changeover = 'Color change (white to color )'
            elif (not filter1['MaterialId'].equals(filter2['MaterialId'])):
                changeover = 'Recipe change (filler)'
            elif (not filter1['TapeWidth'].equals(filter2['TapeWidth'])):
                changeover = 'Cam Change /Spacer change'
            else:
                changeover = 'No Changeover'
            change_data = self.changeover_df.loc[(self.changeover_df['Tape line no'] == machine) & (self.changeover_df['Type of changeover'] == changeover)]
            if len(change_data.values.tolist()) == 0:
                return [changeover, 0, 0, 0, 0]
            else:
                return change_data.values.tolist()[0][1:]

    def filter_with_danier(self,tape_denier,machine_can_be_used):
        filtered_machines = []
        for machine in machine_can_be_used:
            prev_tape_denier = self.machine_available_from[machine][2]
            if(machine in self.step_down):
                if(tape_denier<prev_tape_denier):
                    filtered_machines.append(machine)
            else:
                if(tape_denier>=prev_tape_denier):
                    filtered_machines.append(machine)
        return filtered_machines

    def get_denier_changetime(self,machine,tapedenier,width):
        if(tapedenier>1000 and width in ['Narrow','Wider']):
            prev_tape_denier = self.machine_available_from[machine][2]
            
            time = math.ceil((abs(tapedenier-prev_tape_denier))/150) * 30 
        else:
            time = 0     
        return time 
    def get_recipe_changetime(self,machine,tape_UV,tape_Colour,tape_Filler):
        prev_tape_UV = self.machine_available_from[machine][6]
        prev_tape_colour = self.machine_available_from[machine][5]
        prev_tape_Filler = self.machine_available_from[machine][8]
        total_time = 0
        
        if (prev_tape_UV ==1 and tape_UV == 0):
            time = self.recipe_change_data[(self.recipe_change_data['Recipe1'] == 'UV') & (self.recipe_change_data['Recipe2']=='Non UV')]['Duration in Minutes'].values[0]
            total_time+= time
        if (prev_tape_UV ==0 and tape_UV == 1):
            time = self.recipe_change_data[(self.recipe_change_data['Recipe1'] == 'Non UV') & (self.recipe_change_data['Recipe2']=='UV')]['Duration in Minutes'].values[0]
            total_time+= time
        if (prev_tape_Filler >10 and tape_Filler <=10):
            time = self.recipe_change_data[(self.recipe_change_data['Recipe1'] == 'Filler More Than 10%') & (self.recipe_change_data['Recipe2']=='Filler less Than 10%')]['Duration in Minutes'].values[0]
            total_time+= time
        if (prev_tape_Filler <10 and tape_Filler >=10):
            time = self.recipe_change_data[(self.recipe_change_data['Recipe1'] == 'Filler less Than 10%') & (self.recipe_change_data['Recipe2']=='Filler More Than 10%')]['Duration in Minutes'].values[0]
            total_time+= time
        if (prev_tape_colour=='White' and tape_Colour!='White'):
            time = self.recipe_change_data[(self.recipe_change_data['Recipe1'] == 'White') & (self.recipe_change_data['Recipe2']=='Color')]['Duration in Minutes'].values[0]
            total_time+= time
        if (prev_tape_colour!='White' and tape_Colour=='White'):
            time = self.recipe_change_data[(self.recipe_change_data['Recipe1'] == 'Color') & (self.recipe_change_data['Recipe2']=='White')]['Duration in Minutes'].values[0]
            total_time+= time
            
        return int(total_time)
    
    def get_denier_changetime_step(self,machine,tapedenier,width):
        
        time = 0
        if(tapedenier>1000):
            prev_tape_denier = self.machine_available_from[machine][2]

            if width == 'Wider':
                step = self.denier_step_data[self.denier_step_data['TapeType'] == 'Wider']['DenierChange(1Step)'].values[0]
                duration = self.denier_step_data[self.denier_step_data['TapeType'] == 'Wider']['Duration in Minutes'].values[0]

                time = math.ceil((abs(tapedenier-prev_tape_denier))/int(step))* int(duration)
            if width == 'Narrow':
                step = self.denier_step_data[self.denier_step_data['TapeType'] == 'Narrow']['DenierChange(1Step)'].values[0]
                duration = self.denier_step_data[self.denier_step_data['TapeType'] == 'Narrow']['Duration in Minutes'].values[0]

                time = math.ceil((abs(tapedenier-prev_tape_denier))/int(step)) * int(duration)
        elif (tapedenier <=1000):
            prev_tape_denier = self.machine_available_from[machine][2]

            step = self.denier_step_data[self.denier_step_data['TapeType'] == 'Low Denier']['DenierChange(1Step)'].values[0]
            duration = self.denier_step_data[self.denier_step_data['TapeType'] == 'Low Denier']['Duration in Minutes'].values[0]

            time = math.ceil((abs(tapedenier-prev_tape_denier))/int(step)) * int(duration )   
        else:
            time = 0

        return time 

    def find_nearest_denier(self,prev_value, values_list):
        prev_value = prev_value
        nearest_denier = []
        while(len(values_list)!=0):
            nearest_value = min(values_list, key=lambda x: abs(x - prev_value))
            nearest_denier.append(nearest_value) 
            prev_value  = nearest_value 
            values_list.pop(values_list.index(nearest_value))
        return nearest_denier
     
    def schedule_tapes(self,last_production):
        
        try :
            for i in range(1,10): 
                machine = f'Tape plant {i}'
                ps_starttime_values =self.planned_stop_data[self.planned_stop_data['Tapeline'] ==f'Tapeline {i}']['StartTime'].values
                ps_endtime_values = self.planned_stop_data[self.planned_stop_data['Tapeline'] ==f'Tapeline {i}']['EndTime'].values
                ps_starttime  = 0
                ps_endtime = 0 

                if(last_production[i-1][2] !='white'):
                    color = 1
                else:
                    color = 0  

                if(color == 1):
                    filtered_schedule = self.schedule_df.loc[(self.schedule_df['BestMachine'] == machine)]
                    
                    unique_completion = filtered_schedule['Tape_Completion_date'].unique()
                    
                    for completion in unique_completion: 
                        filtered_schedule1 =  filtered_schedule.loc[filtered_schedule['Tape_Completion_date']==completion]
                        
                        unique_denier = filtered_schedule1['TapeDenier'].unique() 
                        desired_order = self.find_nearest_denier(self.machine_available_from[machine][2],list(unique_denier))
                        filtered_schedule2 = filtered_schedule1.sort_values(by='TapeDenier', key=lambda x: x.map(dict(zip(desired_order, range(len(desired_order))))))
                        for index,row in filtered_schedule2.iterrows():  
                            tape_id = row['TapeId']
                            tape_name = row['Tape_name']
                            tape_denier = row['TapeDenier']
                            tape_UV = row['TapeUv']
                            tape_Colour = row['TapeColour']
                            tape_Filler = row['TapeFiller']
                            print("Tape_id:",tape_id)
                            
                            #colored tapes of this machine
                            if(row['TapeColour'] != 'white'): 
                                if (color ==2):
                                    continue
                                else :
                                    filtered_schedule3 = filtered_schedule.loc[(filtered_schedule['TapeColour'] != 'white')]
                                    unique_color = filtered_schedule3['TapeColour'].unique()    
                                    for colour in unique_color: 
                                        filtered_schedule4 =  filtered_schedule3.loc[filtered_schedule3['TapeColour']==colour]
                                        unique_completion = filtered_schedule4['Tape_Completion_date'].unique()
                                        
                                        for completion in unique_completion: 
                                            filtered_schedule5 =  filtered_schedule4.loc[filtered_schedule4['Tape_Completion_date']==completion]
                                            unique_denier = filtered_schedule4['TapeDenier'].unique()
                                            desired_order = self.find_nearest_denier(self.machine_available_from[machine][2],list(unique_denier))
                                            filtered_schedule6 = filtered_schedule5.sort_values(by='TapeDenier', key=lambda x: x.map(dict(zip(desired_order, range(len(desired_order))))))
                                            
                                            for index,row in filtered_schedule6.iterrows():
                                                
                                                tape_id = row['TapeId']
                                                tape_name = row['Tape_name']
                                                tape_denier = row['TapeDenier']
                                                tape_UV = row['TapeUv']
                                                tape_Colour = row['TapeColour']
                                                tape_Filler = row['TapeFiller']
                                                
                                                prev_tape_id = self.machine_available_from[machine][0]
                                                
                                                recipe_change_starttime = 0
                                                recipe_change_endtime = 0
                                                denier_change_starttime = 0
                                                denier_change_endtime = 0
                                                time_taken = 0
                                                total_demand = 0
                                                completion_time = 0
                                                changeover_data = self.get_changeover_data(prev_tape_id, tape_id, machine)
                                                
                                                recipe_changetime = self.get_recipe_changetime(machine,tape_UV,tape_Colour,tape_Filler)
                                                if recipe_changetime !=0:
                                                    recipe_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                                    recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                    starttime = recipe_change_endtime #production start time
                                                    total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                                    time_taken = round((total_demand) / row['Velocity'])
                                                    completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                                    if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                                        ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                                        ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                                        if (recipe_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                                
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                                        elif (recipe_change_starttime < ps_starttime) & (completion_time < ps_endtime) & (completion_time >ps_starttime):
                                                                
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                                        elif (recipe_change_starttime < ps_starttime) & (completion_time > ps_endtime):
    
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                                        elif (recipe_change_starttime > ps_starttime) & (completion_time > ps_endtime)&(recipe_change_starttime<ps_endtime):
    
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime+ pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken ) 
                                                else:
                                                    denier_changetime = self.get_denier_changetime_step(machine,tape_denier,row['TapeWidth'])
                                                    if denier_changetime == 0 :
                                                        starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')
                                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                                        time_taken = round((total_demand) / row['Velocity'])
                                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                                    else:
                                                    
                                                        denier_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                                        denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                        starttime = denier_change_endtime
                                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                                        time_taken = round((total_demand) / row['Velocity'])
                                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                                        if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                                            ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                                            ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                                            if (denier_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                
                                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                                
                                                            elif (denier_change_starttime < ps_starttime) & (completion_time < ps_endtime)& (completion_time >ps_starttime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                denier_change_endtime =  denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                            elif (denier_change_starttime < ps_starttime) & (completion_time > ps_endtime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                
                                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                            elif (denier_change_starttime > ps_starttime) & (completion_time > ps_endtime)& (denier_change_starttime<ps_endtime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)

                                                self.schedule.append([self.machine_available_from[machine][0], self.machine_available_from[machine][1],
                                                                    self.machine_available_from[machine][2],self.machine_available_from[machine][5],
                                                                    row['TapeId'], row['Tape_name'],row['TapePropertyName'], row['TapeDenier'],row['TapeColour'],row['TapeMarking'],
                                                                    row['Total_Demand'],row['Weft_Demand'],row['Warp_Demand'],row['Warp_rf_Demand'],
                                                                    
                                                                    total_demand,row['Tape_Completion_date'],machine,row['Loom_Location'],row['LoomNo'],
                                                                    row['LoomType'],
                                                                    row['PreLogic_FinalFactor'],
                                                                    denier_change_starttime,denier_change_endtime,recipe_change_starttime,recipe_change_endtime,
                                                                    starttime,completion_time, f"Plan {self.machine_available_from[machine][4]}", 
                                                                    changeover_data[0],changeover_data[2],changeover_data[3],changeover_data[4]])
                                                        
                                                self.machine_available_from[machine] = [tape_id, tape_name, tape_denier,completion_time, 
                                                                                        self.machine_available_from[machine][4] + 1,row['TapeColour'],
                                                                                        row['TapeUv'],row['TapeRP'],row['TapeFiller']]
                                    color = 2
                            elif(row['TapeColour']=='white'):
                                #white tapes of this machine
            
                                prev_tape_id = self.machine_available_from[machine][0]
                                recipe_change_starttime = 0
                                recipe_change_endtime = 0
                                denier_change_starttime = 0
                                denier_change_endtime = 0
                                time_taken = 0
                                total_demand = 0
                                completion_time = 0
                                changeover_data = self.get_changeover_data(prev_tape_id, tape_id, machine)
                                recipe_changetime = self.get_recipe_changetime(machine,tape_UV,tape_Colour,tape_Filler)
                                if recipe_changetime !=0:
                                    recipe_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                    recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                    starttime = recipe_change_endtime #production start time
                                    total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                    time_taken = round((total_demand) / row['Velocity'])
                                    completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                    if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                        ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                        ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                        if (recipe_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                        elif (recipe_change_starttime < ps_starttime) & (completion_time < ps_endtime)& (completion_time >ps_starttime):
                                                
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime+ pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                        elif (recipe_change_starttime < ps_starttime) & (completion_time > ps_endtime):
                                            
                                            
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                        elif (recipe_change_starttime > ps_starttime) & (completion_time > ps_endtime)&(recipe_change_starttime<ps_endtime):
                                            
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)

                                    
                                else:
                                    denier_changetime = self.get_denier_changetime_step(machine,tape_denier,row['TapeWidth'])
                                    if denier_changetime == 0:
                                        starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')
                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                        time_taken = round((total_demand) / row['Velocity'])
                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                    else:
                                        
                                        denier_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                        denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                        
                                        starttime = denier_change_endtime
                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                        time_taken = round((total_demand) / row['Velocity'])
                                        
                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                        
                                        if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                            ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                            ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                            if (denier_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime+ pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                
                                            elif (denier_change_starttime < ps_starttime) & (completion_time < ps_endtime)& (completion_time >ps_starttime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                            elif (denier_change_starttime < ps_starttime) & (completion_time > ps_endtime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                            elif (denier_change_starttime > ps_starttime) & (completion_time > ps_endtime) & (denier_change_starttime<ps_endtime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)

                                self.schedule.append([self.machine_available_from[machine][0], self.machine_available_from[machine][1],
                                                        self.machine_available_from[machine][2],self.machine_available_from[machine][5],
                                                        row['TapeId'], row['Tape_name'],row['TapePropertyName'], row['TapeDenier'],row['TapeColour'],row['TapeMarking'],
                                                        row['Total_Demand'],row['Weft_Demand'],row['Warp_Demand'],row['Warp_rf_Demand'],
                                                        
                                                        total_demand,row['Tape_Completion_date'],machine,row['Loom_Location'],row['LoomNo'],
                                                        row['LoomType'],
                                                        row['PreLogic_FinalFactor'],
                                                        denier_change_starttime,denier_change_endtime,recipe_change_starttime,recipe_change_endtime,
                                                        starttime,completion_time, f"Plan {self.machine_available_from[machine][4]}", 
                                                        changeover_data[0],changeover_data[2],changeover_data[3],changeover_data[4]])
                                self.machine_available_from[machine] = [tape_id, tape_name, tape_denier,completion_time, 
                                                                        self.machine_available_from[machine][4] + 1,
                                                                        row['TapeColour'],row['TapeUv'],row['TapeRP'],row['TapeFiller']]

                else:
                    filtered_schedule = self.schedule_df.loc[(self.schedule_df['BestMachine'] == machine)]
                    
                    unique_completion = filtered_schedule['Tape_Completion_date'].unique()
                    
                    for completion in unique_completion: 
                        filtered_schedule1 =  filtered_schedule.loc[filtered_schedule['Tape_Completion_date']==completion]
                        
                        unique_denier = filtered_schedule1['TapeDenier'].unique() 
                        desired_order = self.find_nearest_denier(self.machine_available_from[machine][2],list(unique_denier))
                        filtered_schedule2 = filtered_schedule1.sort_values(by='TapeDenier', key=lambda x: x.map(dict(zip(desired_order, range(len(desired_order))))))
                        for index,row in filtered_schedule2.iterrows():  
                            tape_id = row['TapeId']
                            tape_name = row['Tape_name']
                            tape_denier = row['TapeDenier']
                            tape_UV = row['TapeUv']
                            tape_Colour = row['TapeColour']
                            tape_Filler = row['TapeFiller']
                            print("Tape_id:",tape_id)
                            #color tapes of this machine
                            if(row['TapeColour'] != 'white'): 
                                if (color==2):
                                    continue
                                else :              

                                    filtered_schedule3 = filtered_schedule.loc[(filtered_schedule['TapeColour'] != 'white')]
                                    
                                    unique_color = filtered_schedule3['TapeColour'].unique() 
                                    
                                    for colour in unique_color: 
                                        
                                        filtered_schedule4 =  filtered_schedule3.loc[filtered_schedule3['TapeColour']==colour]
                                        unique_completion = filtered_schedule4['Tape_Completion_date'].unique()
                                        for completion in unique_completion: 
                                            filtered_schedule5 =  filtered_schedule4.loc[filtered_schedule4['Tape_Completion_date']==completion]
                                            unique_denier = filtered_schedule5['TapeDenier'].unique()
                                            desired_order = self.find_nearest_denier(self.machine_available_from[machine][2],list(unique_denier))
                                            filtered_schedule6 = filtered_schedule5.sort_values(by='TapeDenier', key=lambda x: x.map(dict(zip(desired_order, range(len(desired_order))))))
                                            
                                            for index,row in filtered_schedule6.iterrows():  
                                                tape_id = row['TapeId']
                                                tape_name = row['Tape_name']
                                                tape_denier = row['TapeDenier']
                                                tape_UV = row['TapeUv']
                                                tape_Colour = row['TapeColour']
                                                tape_Filler = row['TapeFiller']
                                                
                                                prev_tape_id = self.machine_available_from[machine][0]
                                                

                                                recipe_change_starttime = 0
                                                recipe_change_endtime = 0
                                                denier_change_starttime = 0
                                                denier_change_endtime = 0
                                                time_taken = 0
                                                total_demand = 0
                                                completion_time = 0
                                                changeover_data = self.get_changeover_data(prev_tape_id, tape_id, machine)
                                                
                                                recipe_changetime = self.get_recipe_changetime(machine,tape_UV,tape_Colour,tape_Filler)
                                                
                                                if recipe_changetime !=0:
                                                    recipe_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                                    recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                    starttime = recipe_change_endtime #production start time
                                                    total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                                    time_taken = round((total_demand) / row['Velocity'])
                                                    completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                                    if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                                        ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                                        ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                                        if (recipe_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                                
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                                        elif (recipe_change_starttime < ps_starttime) & (completion_time < ps_endtime) & (completion_time >ps_starttime):
                                                                
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                                        elif (recipe_change_starttime < ps_starttime) & (completion_time > ps_endtime):

                                                                
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                                        elif (recipe_change_starttime > ps_starttime) & (completion_time > ps_endtime)&(recipe_change_starttime<ps_endtime):

                                                                
                                                            recipe_change_starttime = ps_endtime
                                                            recipe_change_endtime = recipe_change_starttime+ pd.DateOffset(minutes=recipe_changetime)
                                                            starttime = recipe_change_endtime
                                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken ) 
                                                else:
                                                    denier_changetime = self.get_denier_changetime_step(machine,tape_denier,row['TapeWidth'])
                                                    if denier_changetime == 0 :
                                                        starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')
                                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                                        time_taken = round((total_demand) / row['Velocity'])
                                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                                    else:
                                                    
                                                        denier_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                                        denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                        starttime = denier_change_endtime
                                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                                        time_taken = round((total_demand) / row['Velocity'])
                                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                                        if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                                            ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                                            ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                                            if (denier_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                
                                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                                
                                                            elif (denier_change_starttime < ps_starttime) & (completion_time < ps_endtime)& (completion_time >ps_starttime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                denier_change_endtime =  denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                            elif (denier_change_starttime < ps_starttime) & (completion_time > ps_endtime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                
                                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                            elif (denier_change_starttime > ps_starttime) & (completion_time > ps_endtime)& (denier_change_starttime<ps_endtime):
                                                                    
                                                                denier_change_starttime = ps_endtime
                                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                                starttime = denier_change_endtime
                                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)

                                                self.schedule.append([self.machine_available_from[machine][0], self.machine_available_from[machine][1],
                                                                    self.machine_available_from[machine][2],self.machine_available_from[machine][5],
                                                                    row['TapeId'], row['Tape_name'],row['TapePropertyName'], row['TapeDenier'],row['TapeColour'],row['TapeMarking'],
                                                                    row['Total_Demand'],row['Weft_Demand'],row['Warp_Demand'],row['Warp_rf_Demand'],
                                                                    
                                                                    total_demand,row['Tape_Completion_date'],machine,row['Loom_Location'],row['LoomNo'],
                                                                    row['LoomType'],
                                                                    row['PreLogic_FinalFactor'],
                                                                    denier_change_starttime,denier_change_endtime,recipe_change_starttime,recipe_change_endtime,
                                                                    starttime,completion_time, f"Plan {self.machine_available_from[machine][4]}", 
                                                                    changeover_data[0],changeover_data[2],changeover_data[3],changeover_data[4]])
                                                        
                                                self.machine_available_from[machine] = [tape_id, tape_name, tape_denier,completion_time, 
                                                                                        self.machine_available_from[machine][4] + 1,row['TapeColour'],
                                                                                        row['TapeUv'],row['TapeRP'],row['TapeFiller']]
                                    color = 2 
                            elif (row['TapeColour']=='white'):
                                #white tapes of this machine
                                                
                                prev_tape_id = self.machine_available_from[machine][0]
                                recipe_change_starttime = 0
                                recipe_change_endtime = 0
                                denier_change_starttime = 0
                                denier_change_endtime = 0
                                time_taken = 0
                                total_demand = 0
                                completion_time = 0
                                changeover_data = self.get_changeover_data(prev_tape_id, tape_id, machine)
                                recipe_changetime = self.get_recipe_changetime(machine,tape_UV,tape_Colour,tape_Filler)
                                if recipe_changetime !=0:
                                    recipe_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                    recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                    starttime = recipe_change_endtime #production start time
                                    total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                    time_taken = round((total_demand) / row['Velocity'])
                                    completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                    if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                        ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                        ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                        if (recipe_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                        elif (recipe_change_starttime < ps_starttime) & (completion_time < ps_endtime)& (completion_time >ps_starttime):
                                                
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime+ pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                        elif (recipe_change_starttime < ps_starttime) & (completion_time > ps_endtime):
                                            
                                            
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
                                        elif (recipe_change_starttime > ps_starttime) & (completion_time > ps_endtime)&(recipe_change_starttime<ps_endtime):
                                            
                                            recipe_change_starttime = ps_endtime
                                            recipe_change_endtime = recipe_change_starttime + pd.DateOffset(minutes=recipe_changetime)
                                            starttime = recipe_change_endtime
                                            completion_time = recipe_change_endtime + pd.DateOffset(minutes=time_taken)
    
                                else:
                                    denier_changetime = self.get_denier_changetime_step(machine,tape_denier,row['TapeWidth'])
                                    if denier_changetime == 0:
                                        starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')
                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                        time_taken = round((total_demand) / row['Velocity'])
                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                    else:
                                        
                                        denier_change_starttime = datetime.strptime(str(self.machine_available_from[machine][3]), '%Y-%m-%d %H:%M:%S')

                                        denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                        
                                        starttime = denier_change_endtime
                                        total_demand = row['Total_Demand'] +changeover_data[2]+changeover_data[3]
                                        time_taken = round((total_demand) / row['Velocity'])
                                        
                                        completion_time = starttime + pd.DateOffset(minutes=time_taken)
                                        
                                        if len(ps_starttime_values) > 0 and len(ps_endtime_values) > 0:
                                            ps_starttime = pd.Timestamp(ps_starttime_values[0])
                                            ps_endtime = pd.Timestamp(ps_endtime_values[0])
                                            if (denier_change_starttime > ps_starttime) & (completion_time < ps_endtime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime+ pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                                
                                            elif (denier_change_starttime < ps_starttime) & (completion_time < ps_endtime)& (completion_time >ps_starttime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                            elif (denier_change_starttime < ps_starttime) & (completion_time > ps_endtime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)
                                            elif (denier_change_starttime > ps_starttime) & (completion_time > ps_endtime) & (denier_change_starttime<ps_endtime):
                                                
                                                denier_change_starttime = ps_endtime
                                                denier_change_endtime = denier_change_starttime + pd.DateOffset(minutes=denier_changetime)
                                                starttime = denier_change_endtime
                                                completion_time = denier_change_endtime + pd.DateOffset(minutes=time_taken)

                                self.schedule.append([self.machine_available_from[machine][0], self.machine_available_from[machine][1],
                                                        self.machine_available_from[machine][2],self.machine_available_from[machine][5],
                                                        row['TapeId'], row['Tape_name'],row['TapePropertyName'], row['TapeDenier'],row['TapeColour'],row['TapeMarking'],
                                                        row['Total_Demand'],row['Weft_Demand'],row['Warp_Demand'],row['Warp_rf_Demand'],
                                                        
                                                        total_demand,row['Tape_Completion_date'],machine,row['Loom_Location'],row['LoomNo'],
                                                        row['LoomType'],
                                                        row['PreLogic_FinalFactor'],
                                                        denier_change_starttime,denier_change_endtime,recipe_change_starttime,recipe_change_endtime,
                                                        starttime,completion_time, f"Plan {self.machine_available_from[machine][4]}", 
                                                        changeover_data[0],changeover_data[2],changeover_data[3],changeover_data[4]])
                                self.machine_available_from[machine] = [tape_id, tape_name, tape_denier,completion_time, 
                                                                        self.machine_available_from[machine][4] + 1,
                                                                        row['TapeColour'],row['TapeUv'],row['TapeRP'],row['TapeFiller']]
            self.Logs.Logging("File :generate_schedule, Function :  tape_scheduler_schedule_tapes, Status: executed")               
            return [self.schedule]
        except Exception as e :
            self.Logs.Logging(f"File :generate_schedule, Function :  tape_scheduler_schedule_tapes, Status: not executed, Reason : {e}")
    def upload_schedule_to_DB(self,schedule_dff,non_schedule_df):
        try:
            #Initialized cursor to work with DB
            cursor = self.conx.cursor();
            #Truncating changeover table
            #cursor.execute("Truncate table Algo8_Tapeline_Schedule")
            #cursor.execute("Truncate table Algo8_Tapeline_Not_Schedule")
            #Commited the task
            self.conx.commit()  
            #Closed Cursor
            cursor.close()
            print('Tables are Truncated!!')
            self.Logs.Logging("File: schedule, Function: upload_schedule_to_DB, Status: Tables are successfullty Truncated")
        except Exception as e:
            self.Logs.Logging(f"File: schedule, Function: upload_schedule_to_DB, Status: Tables are Not Truncated, Reason: {e}")

            raise "Not able to Truncate the tables"
        
        try: 
            schedule_dff["AuditDateTime"] = datetime.datetime.now()
            schedule_dff.to_sql(name = 'Algo8_Tapeline_Schedule', con = self.engine, if_exists='append', index=False)
            print("Data  uploaded succesfully!")
            self.Logs.Logging("File: Schedule, Function: upload_schedule_to_DB, Status: Tables are added into DB")
        except Exception as e:
            print("Data not uploaded!")
            self.Logs.Logging(f"File: Schedule, Function: upload_schedule_to_DB, Status: Tables are Not added into DB, Reason: {e}")
            print(e)
              
        try: 
            non_schedule_df["AuditDateTime"] = datetime.datetime.now()
            non_schedule_df.to_sql(name = 'Algo8_Tapeline_Not_Schedule', con = self.engine, if_exists='append', index=False)
            print("Data  uploaded succesfully!")
            self.Logs.Logging("File: Schedule, Function: upload_schedule_to_DB, Status: Tables are added into DB")
        except Exception as e:
            print("Data not uploaded!")
            self.Logs.Logging(f"File: Schedule, Function: upload_schedule_to_DB, Status: Tables are Not added into DB, Reason: {e}")
            print(e)
            
def get_schedule():
    print("Generating schedule")
    conn = Conn()
    conn.connect()
    engine = conn.get_engine()
    conx = conn.get_conx()
    production = Production(engine,conx)
    prod_data = production.read_production_data()
    breakdown_data = production.read_breakdown_data()
    #Calculating breakdown_duration 
    prod_df = production.calculate_breakdown_duration(breakdown_data)
    # Instantiate the ProductionAnalyzer class and pass prod_df as an argument
    analyzer = ProductionAnalyzer(prod_df)
    # Perform the required operations
    analyzer.convert_prod_hours_to_minutes()
    analyzer.calculate_actual_time()
    analyzer.calculate_velocity()
    tape_prod = prod_df.copy()
    tape_prod = analyzer.process_tape_prod(tape_prod)
    last_production = analyzer.last_production(tape_prod)
    
    tape_demand = pd.read_excel("C:/Users/ATISHAY/Desktop/KPL_Tapeline/Demand_final.xlsx",index_col=None)
    #read tape_demand from DB
    
    scheduler = Bestmachines(tape_demand,last_production,analyzer,engine,conx)
    
    schedule= scheduler.schedule_tapes(analyzer)
    
    schedule_df = pd.DataFrame(schedule[0][1:], columns=schedule[0][0])
    non_schedule_df = pd.DataFrame(schedule[1][1:], columns=schedule[1][0])
    print("Best_machines_done")
    
    scheduler = TapeScheduler(schedule_df,last_production,engine,conx)
    schedule= scheduler.schedule_tapes(last_production)
    schedule_dff = pd.DataFrame(schedule[0][1:], columns=schedule[0][0])
    #schedule_dff.to_excel('SCHEDULE.xlsx',index = False)
    #non_schedule_df.to_excel('NON-SCHEDULE.xlsx',index = False)
    scheduler.upload_schedule_to_DB(schedule_dff,non_schedule_df)
    print("schedule generated!!")
    return 'Success'